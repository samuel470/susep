# Regras Fiscais PGBL - Brasil 2025

## Limites de Dedução
- **Limite máximo**: 12% da renda bruta anual
- **Condição**: Apenas para quem contribui para previdência oficial (INSS, RPPS, etc.)
- **Sem previdência oficial**: Não há direito à dedução

## Tabela do Imposto de Renda 2025 (ano-calendário 2024)

### Pessoa Física - Mensal
| Faixa | Base de Cálculo (R$) | Alíquota | Parcela a Deduzir |
|-------|----------------------|----------|-------------------|
| 1ª    | Até 2.259,20        | Isento   | -                 |
| 2ª    | 2.259,21 a 2.826,65 | 7,5%     | R$ 169,44         |
| 3ª    | 2.826,66 a 3.751,05 | 15%      | R$ 381,44         |
| 4ª    | 3.751,06 a 4.664,68 | 22,5%    | R$ 662,77         |
| 5ª    | Acima de 4.664,68   | 27,5%    | R$ 896,00         |

### Pessoa Física - Anual
| Faixa | Base de Cálculo (R$) | Alíquota | Parcela a Deduzir |
|-------|----------------------|----------|-------------------|
| 1ª    | Até 27.110,40       | Isento   | -                 |
| 2ª    | 27.110,41 a 33.919,80 | 7,5%   | R$ 2.033,28       |
| 3ª    | 33.919,81 a 45.012,60 | 15%    | R$ 4.577,28       |
| 4ª    | 45.012,61 a 55.976,16 | 22,5%  | R$ 7.953,24       |
| 5ª    | Acima de 55.976,16  | 27,5%    | R$ 10.752,00      |

## Deduções Permitidas (2025)
- **Dependentes**: R$ 2.275,08 por dependente por ano
- **Educação**: Até R$ 3.561,50 por pessoa (titular + dependentes)
- **Saúde**: Sem limite (despesas médicas, odontológicas, psicológicas, etc.)
- **Pensão alimentícia**: Valor integral determinado judicialmente
- **INSS**: Contribuições obrigatórias
- **Previdência privada (PGBL)**: Até 12% da renda bruta (se contribui para previdência oficial)

## Cálculos Importantes

### Base Tributável
```
Base Tributável = Renda Bruta - Deduções Permitidas
```

### Ganho Fiscal PGBL
```
Ganho Fiscal = (Valor Investido PGBL × Alíquota IR) 
```

### Valor Ideal de Contribuição PGBL
```
Valor Ideal = min(12% da Renda Bruta, Valor que zera o IR)
```

### Máximo Ganho Fiscal Possível
```
Máximo Ganho = (12% da Renda Bruta) × Alíquota IR Marginal
```

## Observações Importantes
1. O PGBL reduz a base de cálculo do IR no ano da contribuição
2. Na aposentadoria, o valor total (principal + rendimentos) será tributado
3. É necessário contribuir para previdência oficial para ter direito à dedução
4. O limite de 12% é sobre a renda bruta total do ano
5. Dependentes têm direito às mesmas deduções de educação e saúde

